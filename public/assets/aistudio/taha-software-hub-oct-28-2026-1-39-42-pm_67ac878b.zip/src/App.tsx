/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { FloatingWhatsApp } from './components/common/FloatingWhatsApp';
import { OfflineIndicator } from './components/common/OfflineIndicator';
import { ErrorBoundary } from './components/common/ErrorBoundary';

import { HomePage } from './pages/HomePage';
import { AppsPage } from './pages/AppsPage';
import { AppDetailPage } from './pages/AppDetailPage';
import { CategoriesPage } from './pages/CategoriesPage';
import { WebDesignRequestPage } from './pages/WebDesignRequestPage';
import { ContactPage } from './pages/ContactPage';
import { PrivacyPolicyPage } from './pages/PrivacyPolicyPage';
import { AdminPage } from './pages/AdminPage';
import { NotFoundPage } from './pages/NotFoundPage';

const AppContent: React.FC = () => {
  const { currentPage, isLoading, settings } = useApp();

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage />;
      case 'apps':
        return <AppsPage />;
      case 'app-detail':
        return <AppDetailPage />;
      case 'categories':
        return <CategoriesPage />;
      case 'web-design':
        return <WebDesignRequestPage />;
      case 'contact':
        return <ContactPage />;
      case 'privacy':
        return <PrivacyPolicyPage />;
      case 'admin':
        return <AdminPage />;
      case 'not-found':
      default:
        return <NotFoundPage />;
    }
  };

  return (
    <div
      className="min-h-screen flex flex-col bg-[#0b1329] text-slate-100 selection:bg-cyan-500 selection:text-slate-950 transition-colors"
      style={
        settings.backgroundUrl
          ? {
              backgroundImage: `radial-gradient(ellipse at top, rgba(11,19,41,0.85), rgba(11,19,41,0.98)), url(${settings.backgroundUrl})`,
              backgroundSize: 'cover',
              backgroundAttachment: 'fixed',
              backgroundPosition: 'center',
            }
          : undefined
      }
    >
      <Navbar />

      {/* Non-blocking subtle loading line when fetching fresh data */}
      {isLoading && (
        <div className="w-full h-0.5 bg-slate-900 overflow-hidden">
          <div className="w-1/2 h-full bg-cyan-400 animate-pulse" />
        </div>
      )}

      <main className="flex-1 w-full pb-16">
        {renderPage()}
      </main>

      <Footer />
      <FloatingWhatsApp />
      <OfflineIndicator />
    </div>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <AppProvider>
        <AppContent />
      </AppProvider>
    </ErrorBoundary>
  );
}
